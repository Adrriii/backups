<!DOCTYPE html>
<html data-theme="<?php echo e($defaultPreferences['theme']); ?>" lang="<?php echo e($lang); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="<?php echo e(__('commons.2fauth_description')); ?>" lang="<?php echo e($lang); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex, nofollow">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title><?php echo e(config('app.name')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>" />
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon_lg.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('favicon_lg.png')); ?>" />
    <link rel="manifest" href="<?php echo e(url('manifest.json', [], $isSecure ?? true)); ?>">

</head>
<body>
    <div id="app">
        <app></app>
    </div>
    <script type="text/javascript"
        <?php echo isset($cspNonce) ? "nonce='" . $cspNonce . "'" : ""; ?> >
        var appSettings = <?php echo $appSettings; ?>;
        var appConfig = <?php echo $appConfig; ?>;
        var urls = <?php echo $urls; ?>;
        var defaultPreferences = <?php echo $defaultPreferences->toJson(); ?>;
        var lockedPreferences = <?php echo $lockedPreferences->toJson(); ?>;
        var appVersion = '<?php echo e(config("2fauth.version")); ?>';
        var isDemoApp = <?php echo $isDemoApp; ?>;
        var isTestingApp = <?php echo $isTestingApp; ?>;
        var appLocales = <?php echo $locales; ?>;
    </script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>
</html><?php /**PATH /srv/resources/views/landing.blade.php ENDPATH**/ ?>