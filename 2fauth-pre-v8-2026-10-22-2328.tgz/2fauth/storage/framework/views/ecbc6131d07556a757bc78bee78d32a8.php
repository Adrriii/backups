<?php echo e($slot); ?>

<?php /**PATH /srv/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>